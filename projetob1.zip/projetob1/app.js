var express = require('express'); // Para as rotas
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var sequelize = require('./models').sequelize; // Importando o Sequelize

var indexRouter = require('./routes/index'); // Rota principal do app
var usersRouter = require('./routes/users'); // Rota de usuários
var productsRouter = require('./routes/products'); // Rota de produtos
var cartRouter = require('./routes/cart'); // Rota do carrinho
var paymentRouter = require('./routes/payment'); // Rota de pagamentos

var app = express(); // Ativando a API com o Express

app.use(logger('dev'));
app.use(express.json()); // Permite o uso de JSON
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter); // Cria a rota app/
app.use('/users', usersRouter); // Cria a rota app/users
app.use('/products', productsRouter); // Rota para produtos
app.use('/cart', cartRouter); // Rota para carrinho
app.use('/payment', paymentRouter); // Rota para pagamentos

// Sincronizando o Sequelize
const db = require('./models');

async function applyDataStructure() {
    await db.sequelize.sync({ alter: true }); // Sincroniza o banco de dados
}

applyDataStructure();

// Iniciar o servidor na porta 8081
var port = 8081;
app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
module.exports = app;
