class CartController {
    // O construtor recebe uma instância do CartService e a atribui à variável 'this.cartService'.
    constructor(CartService) {
        this.cartService = CartService;
    }

    // Método assíncrono para adicionar um item ao carrinho.
    async addItem(req, res) {
        // Extrai o 'userId' e o 'item' do corpo da requisição (req.body).
        const { userId, item } = req.body;
        try {
            // Chama o serviço de carrinho (cartService) para adicionar o item ao carrinho do usuário.
            const cart = await this.cartService.addItem(userId, item);
            // Retorna o carrinho atualizado com o status 201 (Criado) em formato JSON.
            res.status(201).json(cart);
        } catch (error) {
            // Em caso de erro, retorna um status 500 (Erro Interno) com uma mensagem de erro.
            res.status(500).json({ error: error.message || 'Erro ao adicionar item ao carrinho.' });
        }
    }

    // Método assíncrono para remover um item do carrinho.
    async removeItem(req, res) {
        // Extrai o 'id' do item dos parâmetros da URL (req.params).
        const { id } = req.params;
        try {
            // Chama o serviço de carrinho para remover o item do carrinho, usando o ID do usuário da requisição (req.user.id).
            await this.cartService.removeItem(req.user.id, id); // Usa req.user.id ao invés de pegar userId do corpo
            // Retorna o status 204 (Sem Conteúdo) se a remoção for bem-sucedida.
            res.status(204).send();
        } catch (error) {
            // Em caso de erro, retorna um status 500 com uma mensagem de erro.
            res.status(500).json({ error: error.message || 'Erro ao remover item do carrinho.' });
        }
    }

    // Método assíncrono para visualizar o carrinho do usuário.
    async viewCart(req, res) {
        try {
            // Chama o serviço de carrinho para visualizar o carrinho do usuário, usando o ID do usuário (req.user.id).
            const cart = await this.cartService.viewCart(req.user.id); // Usa req.user.id
            // Retorna o carrinho em formato JSON com o status 200 (OK).
            res.status(200).json(cart);
        } catch (error) {
            // Em caso de erro, retorna um status 500 com uma mensagem de erro.
            res.status(500).json({ error: error.message || 'Erro ao visualizar carrinho.' });
        }
    }
}

// Exporta a classe CartController para que possa ser usada em outras partes da aplicação.
module.exports = CartController;
