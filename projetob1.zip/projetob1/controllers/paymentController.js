class PaymentController {
    // O construtor recebe uma instância do PaymentService e a atribui a 'this.paymentService'.
    constructor(PaymentService) {
        this.paymentService = PaymentService;
    }

    // Método assíncrono para realizar pagamento com cartão de crédito.
    async payWithCreditCard(req, res) {
        // Extrai o valor total da compra do corpo da requisição (req.body).
        // O 'userId' não é necessário no corpo, pois pode ser obtido através de req.user.id.
        const { valorTotal } = req.body;
        try {
            // Chama o serviço de pagamento (paymentService) para processar o pagamento com o tipo 'cartão de crédito'.
            // Usa o 'req.user.id' para identificar o usuário que está realizando o pagamento.
            const payment = await this.paymentService.processPayment(req.user.id, valorTotal, 'cartão de crédito'); // Usa req.user.id
            // Retorna os detalhes do pagamento com o status 201 (Criado) em formato JSON.
            res.status(201).json(payment);
        } catch (error) {
            // Em caso de erro, retorna um status 500 (Erro Interno) com uma mensagem de erro específica para cartão de crédito.
            res.status(500).json({ error: 'Erro ao processar pagamento com cartão de crédito.' });
        }
    }

    // Método assíncrono para realizar pagamento via PIX.
    async payWithPix(req, res) {
        // Extrai o valor total da compra do corpo da requisição (req.body).
        // O 'userId' também é obtido de req.user.id, como no método anterior.
        const { valorTotal } = req.body;
        try {
            // Chama o serviço de pagamento para processar o pagamento com o tipo 'PIX'.
            // Usa o 'req.user.id' para identificar o usuário que está realizando o pagamento via PIX.
            const payment = await this.paymentService.processPayment(req.user.id, valorTotal, 'PIX'); // Usa req.user.id
            // Retorna os detalhes do pagamento com o status 201 (Criado) em formato JSON.
            res.status(201).json(payment);
        } catch (error) {
            // Em caso de erro, retorna um status 500 com uma mensagem de erro específica para o pagamento via PIX.
            res.status(500).json({ error: 'Erro ao processar pagamento via PIX.' });
        }
    }

    // Método assíncrono para consultar o status de uma transação.
    async getTransactionStatus(req, res) {
        // Extrai o 'transactionId' dos parâmetros da URL (req.params).
        const { transactionId } = req.params;
        try {
            // Chama o serviço de pagamento para obter o status de uma transação específica.
            const payment = await this.paymentService.getStatus(transactionId);
            // Retorna o status da transação em formato JSON com o status 200 (OK).
            res.status(200).json(payment);
        } catch (error) {
            // Em caso de erro, retorna um status 500 com uma mensagem de erro.
            res.status(500).json({ error: 'Erro ao consultar status da transação.' });
        }
    }
}

// Exporta a classe PaymentController para ser usada em outras partes da aplicação.
module.exports = PaymentController;
