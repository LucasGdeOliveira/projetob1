class ProductController {
    // O construtor recebe uma instância do ProductService e a atribui a 'this.productService'.
    constructor(ProductService) {
        this.productService = ProductService;
    }

    // Método assíncrono para criar um novo produto.
    async createProduct(req, res) {
        // Extrai 'nome', 'descricao', 'preco' e 'estoque' do corpo da requisição (req.body).
        const { nome, descricao, preco, estoque } = req.body;
        try {
            // Chama o serviço de produto (productService) para criar um novo produto com os dados fornecidos.
            const newProduct = await this.productService.create(nome, descricao, preco, estoque);
            // Retorna o novo produto criado com o status 201 (Criado) em formato JSON.
            res.status(201).json(newProduct);
        } catch (error) {
            // Em caso de erro, retorna um status 500 (Erro Interno) com uma mensagem de erro.
            res.status(500).json({ error: 'Erro ao criar produto.' });
        }
    }

    // Método assíncrono para obter todos os produtos.
    async getAllProducts(req, res) {
        try {
            // Chama o serviço de produto para listar todos os produtos.
            const products = await this.productService.findAll();
            // Retorna a lista de produtos com o status 200 (OK) em formato JSON.
            res.status(200).json(products);
        } catch (error) {
            // Em caso de erro, retorna um status 500 com uma mensagem de erro.
            res.status(500).json({ error: 'Erro ao listar produtos.' });
        }
    }

    // Método assíncrono para atualizar um produto específico.
    async updateProduct(req, res) {
        // Extrai o 'id' do produto dos parâmetros da URL (req.params).
        const { id } = req.params;
        // Extrai os campos 'nome', 'descricao', 'preco' e 'estoque' do corpo da requisição (req.body).
        const { nome, descricao, preco, estoque } = req.body;
        try {
            // Chama o serviço de produto para atualizar o produto com o ID e os dados fornecidos.
            const updatedProduct = await this.productService.update(id, { nome, descricao, preco, estoque });
            // Retorna o produto atualizado com o status 200 (OK) em formato JSON.
            res.status(200).json(updatedProduct);
        } catch (error) {
            // Em caso de erro, retorna um status 500 com uma mensagem de erro.
            res.status(500).json({ error: 'Erro ao atualizar produto.' });
        }
    }

    // Método assíncrono para deletar um produto específico.
    async deleteProduct(req, res) {
        // Extrai o 'id' do produto dos parâmetros da URL (req.params).
        const { id } = req.params;
        try {
            // Chama o serviço de produto para deletar o produto com o ID fornecido.
            await this.productService.delete(id);
            // Retorna o status 204 (Sem Conteúdo) se a exclusão for bem-sucedida.
            res.status(204).send();
        } catch (error) {
            // Em caso de erro, retorna um status 500 com uma mensagem de erro.
            res.status(500).json({ error: 'Erro ao deletar produto.' });
        }
    }
}

// Exporta a classe ProductController para ser usada em outras partes da aplicação.
module.exports = ProductController;
