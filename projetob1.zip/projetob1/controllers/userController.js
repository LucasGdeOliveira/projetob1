class UserController {
    // O construtor recebe uma instância do UserService e a atribui a 'this.userService'.
    constructor(UserService) {
        this.userService = UserService;
    }

    // Método assíncrono para criar um novo usuário.
    async createUser(req, res) {
        // Extrai 'email', 'data_nasc' e 'password' do corpo da requisição (req.body).
        const { email, data_nasc, password } = req.body;
        try {
            // Chama o serviço de usuário (userService) para criar um novo usuário com os dados fornecidos.
            const newUser = await this.userService.create(email, data_nasc, password);
            // Retorna o novo usuário criado com o status 201 (Criado) em formato JSON.
            res.status(201).json(newUser);
        } catch (error) {
            // Em caso de erro, retorna um status 500 (Erro Interno) com uma mensagem de erro.
            res.status(500).json({ error: 'Ocorreu um erro ao gravar o novo usuário.' });
        }
    }

    // Método assíncrono para encontrar todos os usuários.
    async findAllUsers(req, res) {
        try {
            // Chama o serviço de usuário para listar todos os usuários.
            const AllUsers = await this.userService.findAll();
            // Retorna a lista de usuários com o status 200 (OK) em formato JSON.
            res.status(200).json(AllUsers);
        } catch (error) {
            // Em caso de erro, retorna um status 500 com uma mensagem de erro.
            res.status(500).json({ error: 'Ocorreu um erro ao localizar todos os usuários.' });
        }
    }

    // Método assíncrono para encontrar um usuário específico pelo ID.
    async findUserById(req, res) {
        // Extrai o 'id' da consulta da URL (req.query).
        const { id } = req.query;
        try {
            // Chama o serviço de usuário para encontrar o usuário pelo ID fornecido.
            const User = await this.userService.findById(id);
            // Retorna o usuário encontrado com o status 200 (OK) em formato JSON.
            res.status(200).json(User);
        } catch (error) {
            // Em caso de erro, retorna um status 500 com uma mensagem de erro.
            res.status(500).json({ error: 'Ocorreu um erro ao localizar o usuário pelo ID.' });
        }
    }

    // Método assíncrono para realizar o login de um usuário.
    async login(req, res) {
        // Extrai 'email' e 'password' do corpo da requisição (req.body).
        const { email, password } = req.body;
        try {
            // Chama o serviço de usuário para realizar o login com as credenciais fornecidas.
            const User = await this.userService.login(email, password);
            // Retorna os detalhes do usuário logado com o status 200 (OK) em formato JSON.
            res.status(200).json(User);
        } catch (error) {
            // Em caso de erro, retorna um status 500 com uma mensagem de erro.
            res.status(500).json({ error: 'Erro ao logar o usuário' });
        }
    }
}

// Exporta a classe UserController para ser usada em outras partes da aplicação.
module.exports = UserController;
