const Sequelize = require('sequelize'); // Importa a biblioteca Sequelize para interagir com o banco de dados.

module.exports = (sequelize) => {
    // Define um modelo 'Cart' (Carrinho) utilizando a instância do Sequelize fornecida.
    const Cart = sequelize.define('Cart', {
        id: {
            // Define a coluna 'id' como um número inteiro.
            type: Sequelize.INTEGER,
            autoIncrement: true, // O valor será incrementado automaticamente para cada novo registro.
            primaryKey: true, // Define esta coluna como a chave primária da tabela.
        },
        userId: {
            // Define a coluna 'userId' como um número inteiro.
            type: Sequelize.INTEGER,
            allowNull: false, // A coluna não pode ser nula, obrigatória para o registro.
        },
        itens: {
            // Define a coluna 'itens' para armazenar um array de itens em formato JSON.
            type: Sequelize.JSON,
            allowNull: false, // A coluna não pode ser nula, obrigatória para o registro.
            defaultValue: [], // Define um valor padrão como um vetor vazio, garantindo que não seja nulo.
        },
    });
    return Cart; // Retorna o modelo 'Cart' para ser utilizado em outras partes da aplicação.
};
