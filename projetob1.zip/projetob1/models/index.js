'use strict'; // Ativa o modo estrito do JavaScript para ajudar a detectar erros mais facilmente.

const fs = require('fs'); // Importa o módulo 'fs' para interagir com o sistema de arquivos.
const path = require('path'); // Importa o módulo 'path' para trabalhar com caminhos de arquivos.
const Sequelize = require('sequelize'); // Importa a biblioteca Sequelize para interagir com o banco de dados.
const process = require('process'); // Importa o módulo 'process' para acessar informações do processo atual.
const basename = path.basename(__filename); // Obtém o nome do arquivo atual (sem o caminho completo).
const env = process.env.NODE_ENV || 'development'; // Define o ambiente a partir da variável de ambiente NODE_ENV ou usa 'development' como padrão.
const config = require(__dirname + '/../config/config.json')[env]; // Carrega a configuração do banco de dados do arquivo JSON com base no ambiente.
const db = {}; // Inicializa um objeto vazio para armazenar os modelos de banco de dados.

let sequelize; // Declara a variável sequelize para a instância do Sequelize.
if (config.use_env_variable) {
  // Se a configuração especifica uma variável de ambiente para a conexão:
  sequelize = new Sequelize(process.env[config.use_env_variable], config); // Cria uma nova instância do Sequelize utilizando a variável de ambiente.
} else {
  // Caso contrário, utiliza as credenciais diretamente do arquivo de configuração:
  sequelize = new Sequelize(config.database, config.username, config.password, config);
}

// Lê todos os arquivos do diretório atual e carrega os modelos.
fs
  .readdirSync(__dirname) // Lê o diretório atual.
  .filter(file => {
    // Filtra os arquivos para encontrar apenas aqueles que são modelos.
    return (
      file.indexOf('.') !== 0 && // Ignora arquivos ocultos.
      file !== basename && // Ignora o arquivo atual.
      file.slice(-3) === '.js' && // Considera apenas arquivos .js.
      file.indexOf('.test.js') === -1 // Ignora arquivos de teste.
    );
  })
  .forEach(file => {
    // Para cada arquivo filtrado, importa o modelo e o registra no objeto db.
    const model = require(path.join(__dirname, file))(sequelize, Sequelize.DataTypes);
    db[model.name] = model; // Armazena o modelo no objeto db usando seu nome como chave.
  });

// Associa os modelos uns aos outros, se houver associações definidas.
Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db); // Chama o método associate se estiver definido.
  }
});

// Adiciona a instância do Sequelize e a classe Sequelize ao objeto db.
db.sequelize = sequelize;
db.Sequelize = Sequelize;

// Exporta o objeto db que contém todos os modelos e a instância do Sequelize.
module.exports = db;
