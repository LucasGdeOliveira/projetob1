const Sequelize = require('sequelize'); // Importa a biblioteca Sequelize para interagir com o banco de dados.

module.exports = (sequelize) => {
    // Define um modelo 'Payment' (Pagamento) utilizando a instância do Sequelize fornecida.
    const Payment = sequelize.define('Payment', {
        id: {
            // Define a coluna 'id' como um número inteiro.
            type: Sequelize.INTEGER,
            autoIncrement: true, // O valor será incrementado automaticamente para cada novo registro.
            primaryKey: true, // Define esta coluna como a chave primária da tabela.
        },
        userId: {
            // Define a coluna 'userId' como um número inteiro.
            type: Sequelize.INTEGER,
            allowNull: false, // A coluna não pode ser nula, obrigatória para o registro.
        },
        valorTotal: {
            // Define a coluna 'valorTotal' para armazenar o valor total do pagamento.
            type: Sequelize.DECIMAL(10, 2), // Tipo decimal com até 10 dígitos, sendo 2 após a vírgula.
            allowNull: false, // A coluna não pode ser nula, obrigatória para o registro.
        },
        metodoPagamento: {
            // Define a coluna 'metodoPagamento' como uma string.
            type: Sequelize.STRING,
            allowNull: false, // A coluna não pode ser nula, obrigatória para o registro.
        },
        status: {
            // Define a coluna 'status' como uma string.
            type: Sequelize.STRING,
            allowNull: false, // A coluna não pode ser nula, obrigatória para o registro.
        },
    });
    return Payment; // Retorna o modelo 'Payment' para ser utilizado em outras partes da aplicação.
};
