const Sequelize = require('sequelize'); // Importa a biblioteca Sequelize para interagir com o banco de dados.

module.exports = (sequelize) => {
    // Define um modelo 'Product' (Produto) utilizando a instância do Sequelize fornecida.
    const Product = sequelize.define('Product', {
        id: {
            // Define a coluna 'id' como um número inteiro.
            type: Sequelize.INTEGER,
            autoIncrement: true, // O valor será incrementado automaticamente para cada novo registro.
            primaryKey: true, // Define esta coluna como a chave primária da tabela.
        },
        nome: {
            // Define a coluna 'nome' como uma string.
            type: Sequelize.STRING,
            allowNull: false, // A coluna não pode ser nula, obrigatória para o registro.
        },
        descricao: {
            // Define a coluna 'descricao' como uma string.
            type: Sequelize.STRING,
            allowNull: false, // A coluna não pode ser nula, obrigatória para o registro.
        },
        preco: {
            // Define a coluna 'preco' para armazenar o preço do produto.
            type: Sequelize.DECIMAL(10, 2), // Tipo decimal com até 10 dígitos, sendo 2 após a vírgula.
            allowNull: false, // A coluna não pode ser nula, obrigatória para o registro.
        },
        estoque: {
            // Define a coluna 'estoque' para armazenar a quantidade disponível do produto.
            type: Sequelize.INTEGER,
            allowNull: false, // A coluna não pode ser nula, obrigatória para o registro.
        },
    });
    return Product; // Retorna o modelo 'Product' para ser utilizado em outras partes da aplicação.
};
