const Sequelize = require('sequelize'); // Importa a biblioteca Sequelize para interagir com o banco de dados.

module.exports = (sequelize) => {
    // Define um modelo 'User' (Usuário) utilizando a instância do Sequelize fornecida.
    const User = sequelize.define('User', {
        id: {
            // Define a coluna 'id' como um número inteiro.
            type: Sequelize.INTEGER,
            autoIncrement: true, // O valor será incrementado automaticamente para cada novo registro.
            primaryKey: true // Define esta coluna como a chave primária da tabela.
        },
        email: {
            // Define a coluna 'email' como uma string.
            type: Sequelize.STRING,
            unique: true, // Garante que o valor do e-mail seja único na tabela.
            allowNull: false // A coluna não pode ser nula, obrigatória para o registro.
        },
        data_nasc: {
            // Define a coluna 'data_nasc' para armazenar a data de nascimento do usuário.
            type: Sequelize.DATE, // Tipo de dado para armazenar datas.
            allowNull: true // A coluna pode ser nula, pois não é obrigatória.
        },
        password: {
            // Define a coluna 'password' para armazenar a senha do usuário.
            type: Sequelize.STRING,
            allowNull: false // A coluna não pode ser nula, obrigatória para o registro.
        }
    });
    return User; // Retorna o modelo 'User' para ser utilizado em outras partes da aplicação.
};
