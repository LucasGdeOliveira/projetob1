const express = require('express'); // Importa a biblioteca Express para criar o servidor e gerenciar rotas.
const router = express.Router(); // Cria um novo objeto de roteador do Express para definir as rotas relacionadas ao carrinho.
const db = require('../models'); // Importa os modelos do banco de dados.
const CartService = require('../services/cartservice'); // Importa o serviço de carrinho para gerenciar a lógica de negócios do carrinho.
const CartController = require('../controllers/cartController'); // Importa o controlador de carrinho para gerenciar as requisições relacionadas ao carrinho.
const auth = require('../auth'); // Importa o middleware de autenticação.

const cartService = new CartService(db.Cart); // Cria uma instância do CartService, passando o modelo Cart do banco de dados.
const cartController = new CartController(cartService); // Cria uma instância do CartController, passando o cartService como dependência.

// Rota para adicionar item ao carrinho
router.post('/add', auth.verifyToken, cartController.addItem.bind(cartController));
// Utiliza o método HTTP POST na rota '/add'. O middleware 'auth.verifyToken' é chamado primeiro para garantir que o usuário esteja autenticado.
// Em seguida, o método 'addItem' do 'cartController' é chamado para adicionar um item ao carrinho.

// Rota para remover item do carrinho
router.delete('/remove/:id', auth.verifyToken, cartController.removeItem.bind(cartController));
// Utiliza o método HTTP DELETE na rota '/remove/:id'. O middleware 'auth.verifyToken' é chamado para garantir que o usuário esteja autenticado.
// O método 'removeItem' do 'cartController' é chamado para remover um item do carrinho com o ID especificado na URL.

// Rota para visualizar carrinho
router.get('/', auth.verifyToken, cartController.viewCart.bind(cartController));
// Utiliza o método HTTP GET na rota '/'. O middleware 'auth.verifyToken' é chamado para garantir que o usuário esteja autenticado.
// O método 'viewCart' do 'cartController' é chamado para retornar os itens do carrinho do usuário.

module.exports = router; // Exporta o objeto de roteador para ser utilizado na aplicação.
