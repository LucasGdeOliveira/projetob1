var express = require('express'); // Importa a biblioteca Express para criar o servidor e gerenciar rotas.
var router = express.Router(); // Cria um novo objeto de roteador do Express para definir as rotas da aplicação.

/* GET home page. */
// Define uma rota HTTP GET para o caminho raiz ('/') da aplicação.
router.get('/', function(req, res, next) {
  // Função que será executada quando uma requisição GET for feita para a rota raiz.
  res.render('index', { title: 'Express' }); // Renderiza a view 'index' e passa um objeto com a propriedade 'title' com valor 'Express'.
});

// Exporta o objeto de roteador para ser utilizado na aplicação principal.
module.exports = router;
