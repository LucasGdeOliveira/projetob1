const express = require('express'); // Importa a biblioteca Express para criar o servidor e gerenciar rotas.
const router = express.Router(); // Cria um novo objeto de roteador do Express para definir as rotas relacionadas ao pagamento.
const db = require('../models'); // Importa os modelos do banco de dados.
const PaymentService = require('../services/paymentService'); // Importa o serviço de pagamento para gerenciar a lógica de negócios do pagamento.
const PaymentController = require('../controllers/paymentController'); // Importa o controlador de pagamento para gerenciar as requisições relacionadas ao pagamento.
const auth = require('../auth'); // Importa o middleware de autenticação.

const paymentService = new PaymentService(db.Payment); // Cria uma instância do PaymentService, passando o modelo Payment do banco de dados.
const paymentController = new PaymentController(paymentService); // Cria uma instância do PaymentController, passando o paymentService como dependência.

// Rota para pagamento com cartão de crédito
router.post('/credit-card', auth.verifyToken, paymentController.payWithCreditCard.bind(paymentController));
// Utiliza o método HTTP POST na rota '/credit-card'. O middleware 'auth.verifyToken' é chamado primeiro para garantir que o usuário esteja autenticado.
// Em seguida, o método 'payWithCreditCard' do 'paymentController' é chamado para processar o pagamento com cartão de crédito.

// Rota para pagamento via Pix
router.post('/pix', auth.verifyToken, paymentController.payWithPix.bind(paymentController));
// Utiliza o método HTTP POST na rota '/pix'. O middleware 'auth.verifyToken' é chamado para garantir que o usuário esteja autenticado.
// O método 'payWithPix' do 'paymentController' é chamado para processar o pagamento via PIX.

// Rota para consultar status da transação
router.get('/status/:transactionId', auth.verifyToken, paymentController.getTransactionStatus.bind(paymentController));
// Utiliza o método HTTP GET na rota '/status/:transactionId'. O middleware 'auth.verifyToken' é chamado para garantir que o usuário esteja autenticado.
// O método 'getTransactionStatus' do 'paymentController' é chamado para retornar o status da transação especificada pelo 'transactionId'.

module.exports = router; // Exporta o objeto de roteador para ser utilizado na aplicação.
