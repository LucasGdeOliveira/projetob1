const express = require('express'); // Importa a biblioteca Express para criar o servidor e gerenciar rotas.
const router = express.Router(); // Cria um novo objeto de roteador do Express para definir as rotas relacionadas a produtos.
const db = require('../models'); // Importa os modelos do banco de dados.
const ProductService = require('../services/productservice'); // Importa o serviço de produtos para gerenciar a lógica de negócios relacionada a produtos.
const ProductController = require('../controllers/productController'); // Importa o controlador de produtos para gerenciar as requisições relacionadas a produtos.

const productService = new ProductService(db.Product); // Cria uma instância do ProductService, passando o modelo Product do banco de dados.
const productController = new ProductController(productService); // Cria uma instância do ProductController, passando o productService como dependência.

// Rota para criar produto
router.post('/', productController.createProduct.bind(productController));
// Utiliza o método HTTP POST na rota '/'. O método 'createProduct' do 'productController' é chamado para criar um novo produto.

// Rota para listar todos os produtos
router.get('/', productController.getAllProducts.bind(productController));
// Utiliza o método HTTP GET na rota '/'. O método 'getAllProducts' do 'productController' é chamado para listar todos os produtos.

// Rota para atualizar produto
router.put('/:id', productController.updateProduct.bind(productController));
// Utiliza o método HTTP PUT na rota '/:id', onde ':id' é um parâmetro de rota que representa o ID do produto.
// O método 'updateProduct' do 'productController' é chamado para atualizar as informações do produto especificado pelo ID.

// Rota para deletar produto
router.delete('/:id', productController.deleteProduct.bind(productController));
// Utiliza o método HTTP DELETE na rota '/:id', onde ':id' é um parâmetro de rota que representa o ID do produto.
// O método 'deleteProduct' do 'productController' é chamado para deletar o produto especificado pelo ID.

module.exports = router; // Exporta o objeto de roteador para ser utilizado na aplicação.
