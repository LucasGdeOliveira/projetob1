const express = require('express'); // Importa a biblioteca Express para criar o servidor e gerenciar rotas.
const router = express.Router(); // Cria um novo objeto de roteador do Express para definir as rotas relacionadas a usuários.
const auth = require('../auth'); // Importa o middleware de autenticação para proteger algumas rotas.
const db = require('../models'); // Importa os modelos do banco de dados.
const UserService = require('../services/userService'); // Importa o serviço de usuários para gerenciar a lógica de negócios relacionada a usuários.
const UserController = require('../controllers/userController'); // Importa o controlador de usuários para gerenciar as requisições relacionadas a usuários.

const userService = new UserService(db.User); // Cria uma instância do UserService, passando o modelo User do banco de dados.
const userController = new UserController(userService); // Cria uma instância do UserController, passando o userService como dependência.

// Rota para login
router.post('/login', async (req, res) => {
    userController.login(req, res); // Chama o método 'login' do 'userController' para autenticar o usuário.
});

// Rota para registrar novo usuário
router.post('/novouser', async (req, res) => {
    userController.createUser(req, res); // Chama o método 'createUser' do 'userController' para registrar um novo usuário.
});

// Rota para retornar todos os usuários (protegida)
router.get('/allusers', auth.verifyToken, async (req, res) => {
    userController.findAllUsers(req, res); // Chama o método 'findAllUsers' do 'userController' para listar todos os usuários, após verificar o token de autenticação.
});

// Rota para retornar um usuário pelo ID
router.get('/getUserById', async (req, res) => {
    userController.findUserById(req, res); // Chama o método 'findUserById' do 'userController' para buscar um usuário específico.
});

module.exports = router; // Exporta o objeto de roteador para ser utilizado na aplicação.
