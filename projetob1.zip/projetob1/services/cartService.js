// services/cartService.js

class CartService {
    // Construtor da classe que recebe o modelo Cart como parâmetro.
    constructor(CartModel) {
        this.Cart = CartModel; // Armazena o modelo Cart para operações futuras.
    }

    // Método assíncrono para adicionar um item ao carrinho de um usuário.
    async addItem(userId, item) {
        // Busca o carrinho do usuário pelo userId.
        let cart = await this.Cart.findOne({ where: { userId } });
        
        // Se o carrinho não existir, cria um novo carrinho com o userId e um vetor vazio de itens.
        if (!cart) {
            cart = await this.Cart.create({ userId, itens: [] });
        }
        
        // Obtém a lista de itens existentes no carrinho (ou um vetor vazio se não houver itens).
        const itens = cart.itens || [];
        itens.push(item); // Adiciona o novo item à lista de itens.

        // Atualiza o carrinho com a nova lista de itens e retorna o carrinho atualizado.
        return await cart.update({ itens });
    }

    // Método assíncrono para remover um item do carrinho usando seu ID.
    async removeItem(id) {
        // Busca o carrinho pelo ID fornecido.
        const cart = await this.Cart.findByPk(id);
        // Remove o carrinho encontrado e retorna o resultado da operação.
        return await cart.destroy();
    }

    // Método assíncrono para visualizar o carrinho de um usuário.
    async viewCart(userId) {
        // Busca e retorna o carrinho do usuário pelo userId.
        return await this.Cart.findOne({ where: { userId } });
    }
}

module.exports = CartService; // Exporta a classe CartService para uso em outros módulos.
