// services/paymentService.js

class PaymentService {
    // Construtor da classe que recebe o modelo Payment como parâmetro.
    constructor(PaymentModel) {
        this.Payment = PaymentModel; // Armazena o modelo Payment para operações futuras.
    }

    // Método assíncrono para processar um pagamento.
    async processPayment(userId, valorTotal, metodoPagamento) {
        const status = 'Pagamento Concluido'; // Define o status do pagamento como 'Pagamento Concluído'.

        // Cria um novo registro de pagamento com as informações fornecidas e retorna o pagamento criado.
        return await this.Payment.create({ userId, valorTotal, metodoPagamento, status });
    }

    // Método assíncrono para obter o status de uma transação com base no ID da transação.
    async getStatus(transactionId) {
        // Busca e retorna o pagamento correspondente ao transactionId fornecido.
        return await this.Payment.findByPk(transactionId);
    }
}

module.exports = PaymentService; // Exporta a classe PaymentService para uso em outros módulos.
