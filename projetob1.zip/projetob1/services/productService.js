// services/productService.js

class ProductService {
    // Construtor da classe que recebe o modelo Product como parâmetro.
    constructor(ProductModel) {
        this.Product = ProductModel; // Armazena o modelo Product para operações futuras.
    }

    // Método assíncrono para criar um novo produto.
    async create(nome, descricao, preco, estoque) {
        // Chama o método create do modelo Product para adicionar um novo produto no banco de dados.
        return await this.Product.create({ nome, descricao, preco, estoque });
    }

    // Método assíncrono para buscar todos os produtos.
    async findAll() {
        // Chama o método findAll do modelo Product para recuperar todos os produtos do banco de dados.
        return await this.Product.findAll();
    }

    // Método assíncrono para atualizar um produto existente.
    async update(id, data) {
        // Busca o produto pelo ID fornecido.
        const product = await this.Product.findByPk(id);
        // Atualiza o produto com os novos dados e retorna o produto atualizado.
        return await product.update(data);
    }

    // Método assíncrono para deletar um produto pelo ID.
    async delete(id) {
        // Busca o produto pelo ID fornecido.
        const product = await this.Product.findByPk(id);
        // Remove o produto do banco de dados e retorna o resultado da operação de remoção.
        return await product.destroy();
    }
}

module.exports = ProductService; // Exporta a classe ProductService para uso em outros módulos.
