// ./services/userService.js
const auth = require('../auth'); // Importa o módulo de autenticação para gerar tokens.
const bcrypt = require('bcrypt'); // Importa o módulo bcrypt para hash de senhas.
var round_salts = 10; // Define o número de rounds para o hashing da senha.

const db = require('../models'); // Importa os modelos do banco de dados.

class UserService {
    constructor(UserModel) {
        this.User = UserModel; // Inicializa o modelo de usuário.
    }

    // Método para criar um novo usuário
    async create(email, data_nasc, password) {
        try {
            // Faz o hash da senha antes de salvar
            const hashpassword = await bcrypt.hash(password, parseInt(round_salts));
            // Cria um novo usuário no banco de dados
            const newUser = await this.User.create({
                email,
                data_nasc,
                password: hashpassword // Armazena a senha hash
            });

            // Retorna o novo usuário ou null se não foi criado
            return newUser ? newUser : null;
        } catch (error) {
            throw error; // Lança erro caso ocorra alguma falha
        }
    }

    // Método para retornar todos os usuários
    async findAll() {
        try {
            // Busca todos os usuários no banco de dados
            const AllUsers = await this.User.findAll();
            // Retorna todos os usuários ou null se não encontrar
            return AllUsers ? AllUsers : null;
        } catch (error) {
            throw error; // Lança erro caso ocorra alguma falha
        }
    }

    // Método para retornar o usuário pelo ID
    async findById(id) {
        try {
            // Busca o usuário pelo ID
            const User = await this.User.findByPk(id);
            // Retorna o usuário encontrado ou null se não encontrar
            return User ? User : null;
        } catch (error) {
            throw error; // Lança erro caso ocorra alguma falha
        }
    }

    // Método para login de usuário
    async login(email, password) {
        try {
            // Busca o usuário pelo email
            const User = await this.User.findOne({
                where: { email }
            });
            // Se o usuário existe, verifica se a senha está correta
            if (User) {
                // Compara a senha fornecida com a senha hash armazenada
                if (await bcrypt.compare(password, User.password)) {
                    // Gera um token de autenticação para o usuário
                    const token = await auth.generateToken(User);
                    User.dataValues.token = token; // Adiciona o token aos dados do usuário
                    User.dataValues.password = ''; // Remove a senha dos dados retornados
                } else {
                    throw new Error('Senha Invalida'); // Lança erro se a senha estiver incorreta
                }
            }
            // Retorna o usuário encontrado ou null
            return User ? User : null;
        } catch (error) {
            throw error; // Lança erro caso ocorra alguma falha
        }
    }
}

module.exports = UserService; // Exporta a classe UserService para ser utilizada em outros módulos
